const connectionString = "mongodb://localhost:27017/demo";
module.exports = {
    "development": connectionString,
    "production": null
}