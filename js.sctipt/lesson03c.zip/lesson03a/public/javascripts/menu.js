//при завантаженні сторінки 
//визначити її адресу
//знайти пункт меню з такою адресою
//додати йому клас active
$(function() {
    const menuitem = $('a[href="' + window.location.pathname + '"]');
    menuitem.parent().addClass('active');
    menuitem.append('<span class="sr-only">(current)</span>');
});